package info.bliki.wiki.dump;


public class WikiArticle {
	private String text;
	private String title;
	private String timeStamp;
	
	public String getText() {
		return text;
	}

	public String getTitle() {
		return title;
	}

	public void setText(String newText) {
		text = newText;
	}

	public void setTitle(String newTitle) {
		title = newTitle;
	}

	@Override
	public String toString() {
		return title;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
}
