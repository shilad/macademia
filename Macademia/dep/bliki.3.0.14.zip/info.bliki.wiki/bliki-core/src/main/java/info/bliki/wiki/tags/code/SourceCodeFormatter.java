package info.bliki.wiki.tags.code;

/**
 * Displays source code with syntax highlighting
 *
 */
public interface SourceCodeFormatter
{
	public String filter(String content);
}
